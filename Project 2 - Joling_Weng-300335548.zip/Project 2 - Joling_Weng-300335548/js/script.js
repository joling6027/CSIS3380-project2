//reference from website: https://medium.com/geekculture/building-a-javascript-pagination-as-simple-as-possible-a9c32dbf4ac1
//reference from youtube: https://www.youtube.com/watch?v=IqYiVHrO2U8
//Author: Joling Weng 300335548

//get the Nodelist
const contactItem = document.querySelectorAll(".contact-item");
//get the wrapper
const contactList = document.getElementsByTagName("ul")[0];
//get the element for insert page button element
const paginator = document.querySelector(".pagination");
//change the Nodelist into an array
const contactsArray = Array.from(contactItem);
//hide original contact list from screen first
contactsArray.map((item) => {
  item.style.display = "none";
});

const numOfContacts = contactsArray.length;
const numPerPage = 10;
let currentPage = 1;
const numOfPages = Math.ceil(numOfContacts / numPerPage);

//To slice the contact list array and append to wrapper
function DisplayContacts(contacts, wrapper, rows_per_page, page) {
  wrapper.innerHTML = "";
  page--;

  let start = rows_per_page * page;
  let end = start + rows_per_page;
  let paginateItems = contacts.slice(start, end);

  for (let i = 0; i < paginateItems.length; i++) {
    let contact = paginateItems[i];

    wrapper.appendChild(contact);
    contact.style.display = "block";
    console.log(wrapper);
  }
}

//assign page number to button and append to wrapper
function SetUpPagination(contacts, wrapper, rows_per_page) {
  wrapper.innerHTML = "";

  let page_count = Math.ceil(contacts.length / rows_per_page);
  for (let i = 1; i < page_count + 1; i++) {
    let btn = PaginationBtn(i, contacts);
    wrapper.appendChild(btn);
  }
}

//create button element and event listener
function PaginationBtn(page, contacts) {
  let button = document.createElement("button");
  button.innerText = page;

  if (currentPage == page) button.classList.add("pageNum");

  button.addEventListener("click", () => {
    currentPage = page;
    DisplayContacts(contacts, contactList, numPerPage, currentPage);
  });
  return button;
}

//execute functions
DisplayContacts(contactsArray, contactList, numPerPage, currentPage);
SetUpPagination(contactsArray, paginator, numPerPage);
